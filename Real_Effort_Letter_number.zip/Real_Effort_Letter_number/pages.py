from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
import time
import random


class countdown(Page):
    form_model = 'player'
    timeout_seconds = 5

    def is_displayed(self):
        return self.round_number == 1

    def before_next_page(self):
        self.player.participant.vars['expiry'] = time.time() + (3 * 30)


class RealEffort(Page):
    form_model = 'player'
    form_fields = ['digit_response']

    timeout_seconds = 90

    def get_timeout_seconds(self):
        return self.player.participant.vars['expiry'] - time.time()

    def is_displayed(self):
        return self.get_timeout_seconds() > 1

    def before_next_page(self):
        return{
            self.player.correct_answers(),
            self.player.sum_answer(),
            self.player.prev_correct(),
            self.player.show_answer(),
            self.group.set_treatment(),
        }


class WaitAfterTaskPage(WaitPage):

    body_text = "Please wait while the other participant in your group makes their decisions."

    def is_displayed(self):
        return self.round_number == Constants.num_rounds


class Thanks(Page):
    form_model = 'player'

    def is_displayed(self):
        return self.round_number == Constants.num_rounds


page_sequence = [Welcome,
                 countdown,
                 RealEffort,
                 Thanks]
