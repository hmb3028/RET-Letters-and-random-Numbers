from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)

import random
import itertools
author = 'Hamideh Mohtashami Borzadaran'

doc = """
This is a real effort task where subjects are asked to identify a number 
assigned to a specific letter. The letters are fixed and it is the numbers
that vary. Subject identify the number assigned to a letter and click the
next button. Once the button is pressed a new random letter will be generated 
and the a new number for each letter will also be randomly generated. With 
this code the subjects will be able to see the number of correct answers they provided.
"""


class Constants(BaseConstants):
    name_in_url = 'Experiment2'
    players_per_group = 2
    num_rounds = 50

# """Amount allocated to each player"""


class Subsession(BaseSubsession):
    def creating_session(self):
        # real effort task
        for p in self.get_players():
            letter = [str('A'), str('B'), str('C'), str('D'), str('E'), str('F'), str('G'), str('H'), str('I'),
                      str('J'), str('K'), str('L'), str('M'), str('N'), str('O'), str('P'), str('Q'), str('R'),
                      str('S'), str('T'), str('U'), str('V'), str('W'), str('X'), str('Y'), str('Z')]
            p.random_letter = random.choice(letter)
        for p in self.get_players():
            rand = [int(1), int(2), int(3), int(4), int(5), int(6), int(7), int(8), int(9), int(10), int(11),
                    int(12), int(13), int(14), int(15), int(16), int(17), int(18), int(19), int(20), int(21),
                    int(22), int(23), int(24), int(25), int(26), int(27), int(28), int(29), int(30), int(31),
                    int(32), int(33), int(34), int(35), int(36), int(37), int(38), int(39), int(40), int(41),
                    int(42), int(43), int(44), int(45), int(46), int(47), int(48), int(49), int(50), int(51),
                    int(52), int(53), int(54), int(55), int(56), int(57), int(58), int(59), int(60), int(61),
                    int(62), int(63), int(64), int(65), int(66), int(67), int(68), int(69), int(70), int(71),
                    int(72), int(73), int(74), int(75), int(76), int(77), int(78), int(79), int(80), int(81),
                    int(82), int(83), int(84), int(85), int(86), int(87), int(88), int(89), int(90), int(91),
                    int(92), int(93), int(94), int(95), int(96), int(97), int(98), int(99), int(100)]
            p.digits1 = random.choice(rand)
            rand.remove(p.digits1)
            p.digits2 = random.choice(rand)
            rand.remove(p.digits2)
            p.digits3 = random.choice(rand)
            rand.remove(p.digits3)
            p.digits4 = random.choice(rand)
            rand.remove(p.digits4)
            p.digits5 = random.choice(rand)
            rand.remove(p.digits5)
            p.digits6 = random.choice(rand)
            rand.remove(p.digits6)
            p.digits7 = random.choice(rand)
            rand.remove(p.digits7)
            p.digits8 = random.choice(rand)
            rand.remove(p.digits8)
            p.digits9 = random.choice(rand)
            rand.remove(p.digits9)
            p.digits10 = random.choice(rand)
            rand.remove(p.digits10)
            p.digits11 = random.choice(rand)
            rand.remove(p.digits11)
            p.digits12 = random.choice(rand)
            rand.remove(p.digits12)
            p.digits13 = random.choice(rand)
            rand.remove(p.digits13)
            p.digits14 = random.choice(rand)
            rand.remove(p.digits14)
            p.digits15 = random.choice(rand)
            rand.remove(p.digits15)
            p.digits16 = random.choice(rand)
            rand.remove(p.digits16)
            p.digits17 = random.choice(rand)
            rand.remove(p.digits17)
            p.digits18 = random.choice(rand)
            rand.remove(p.digits18)
            p.digits19 = random.choice(rand)
            rand.remove(p.digits19)
            p.digits20 = random.choice(rand)
            rand.remove(p.digits20)
            p.digits21 = random.choice(rand)
            rand.remove(p.digits21)
            p.digits22 = random.choice(rand)
            rand.remove(p.digits22)
            p.digits23 = random.choice(rand)
            rand.remove(p.digits23)
            p.digits24 = random.choice(rand)
            rand.remove(p.digits24)
            p.digits25 = random.choice(rand)
            rand.remove(p.digits25)
            p.digits26 = random.choice(rand)
            rand.remove(p.digits26)

            # roles and endowment
        for p in self.get_players():
            if p.random_letter == 'A':
                p.answer = p.digits1
            elif p.random_letter == 'B':
                p.answer = p.digits2
            elif p.random_letter == 'C':
                p.answer = p.digits3
            elif p.random_letter == 'D':
                p.answer = p.digits4
            elif p.random_letter == 'E':
                p.answer = p.digits5
            elif p.random_letter == 'F':
                p.answer = p.digits6
            elif p.random_letter == 'G':
                p.answer = p.digits7
            elif p.random_letter == 'H':
                p.answer = p.digits8
            elif p.random_letter == 'I':
                p.answer = p.digits9
            elif p.random_letter == 'J':
                p.answer = p.digits10
            elif p.random_letter == 'K':
                p.answer = p.digits11
            elif p.random_letter == 'L':
                p.answer = p.digits12
            elif p.random_letter == 'M':
                p.answer = p.digits13
            elif p.random_letter == 'N':
                p.answer = p.digits14
            elif p.random_letter == 'O':
                p.answer = p.digits15
            elif p.random_letter == 'P':
                p.answer = p.digits16
            elif p.random_letter == 'Q':
                p.answer = p.digits17
            elif p.random_letter == 'R':
                p.answer = p.digits18
            elif p.random_letter == 'S':
                p.answer = p.digits19
            elif p.random_letter == 'T':
                p.answer = p.digits20
            elif p.random_letter == 'U':
                p.answer = p.digits21
            elif p.random_letter == 'V':
                p.answer = p.digits22
            elif p.random_letter == 'W':
                p.answer = p.digits23
            elif p.random_letter == 'X':
                p.answer = p.digits24
            elif p.random_letter == 'Y':
                p.answer = p.digits25
            elif p.random_letter == 'Z':
                p.answer = p.digits26


class Group(BaseGroup):
    sum_of_correct = models.IntegerField(label='', initial=0)

    def set_treatment(self):
        self.in_round(Constants.num_rounds).sum_of_correct = sum([p.in_round(Constants.num_rounds).total_correct for
                                                                  p in self.get_players()])
        for p in self.get_players():
            p.in_round(Constants.num_rounds).other_correct = \
                self.in_round(Constants.num_rounds).sum_of_correct - p.in_round(Constants.num_rounds).total_correct


class Player(BasePlayer):
    digits1 = models.IntegerField()
    digits2 = models.IntegerField()
    digits3 = models.IntegerField()
    digits4 = models.IntegerField()
    digits5 = models.IntegerField()
    digits6 = models.IntegerField()
    digits7 = models.IntegerField()
    digits8 = models.IntegerField()
    digits9 = models.IntegerField()
    digits10 = models.IntegerField()
    digits11 = models.IntegerField()
    digits12 = models.IntegerField()
    digits13 = models.IntegerField()
    digits14 = models.IntegerField()
    digits15 = models.IntegerField()
    digits16 = models.IntegerField()
    digits17 = models.IntegerField()
    digits18 = models.IntegerField()
    digits19 = models.IntegerField()
    digits20 = models.IntegerField()
    digits21 = models.IntegerField()
    digits22 = models.IntegerField()
    digits23 = models.IntegerField()
    digits24 = models.IntegerField()
    digits25 = models.IntegerField()
    digits26 = models.IntegerField()

    random_letter = models.StringField()
    digit_response = models.IntegerField(label='', min=0, max=100)
    answer = models.IntegerField()
    correct = models.IntegerField(label='', initial=0)
    incorrect = models.IntegerField(label='', initial=0)

    def correct_answers(self):
        if self.answer == self.digit_response:
            self.correct = 1
        elif self.digit_response == '':
            self.correct = 0
            self.incorrect = 0
        elif self.digit_response == 0:
            self.correct = 0
            self.incorrect = 0
        else:
            self.incorrect = 1

    totalNumAttempted = models.FloatField()
    totalNumCorrect = models.IntegerField()
    total_correct = models.IntegerField(label='', initial=0)
    other_correct = models.IntegerField(label='', initial=0)
    sum_of_correct = models.IntegerField(label='', initial=0)
    total_incorrect = models.IntegerField(label='', initial=0)
    correct_prev = models.IntegerField(label='', initial=0)

    def sum_answer(self):
        self.totalNumCorrect = sum([p.correct for p in self.in_all_rounds()])

    def prev_correct(self):
        if self.round_number < Constants.num_rounds:
            self.in_round(self.round_number+1).correct_prev = self.in_round(self.round_number).totalNumCorrect
        elif self.round_number == Constants.num_rounds:
            self.in_round(self.round_number).correct_prev = self.in_round(self.round_number).totalNumCorrect
        else:
            self.correct_prev = 0

    def show_answer(self):
        self.in_round(Constants.num_rounds).total_correct = sum([p.correct for p in self.in_all_rounds()])
        self.in_round(Constants.num_rounds).total_incorrect = sum([p.incorrect for p in self.in_all_rounds()])
        self.in_round(Constants.num_rounds).totalNumAttempted = \
            self.in_round(Constants.num_rounds).total_correct + self.in_round(Constants.num_rounds).total_incorrect
        self.in_round(Constants.num_rounds).sum_of_correct = \
            self.in_round(Constants.num_rounds).group.sum_of_correct
    ##########################################################



